<?php
    return array(
        'coinDb'=>"coin.db",
        'perCoin'=>1,
        'dayCoin'=>10,
        'createCoin'=>1,
        "addMsg"=>"恭喜你抢到了<span style='color: skyblue;font-weight: 700;'> 1 </span>枚金币",
        "createUserMsg"=>"这是你第 <span style='color: skyblue;font-weight: 700;'> 1 </span> 次抢金币，先送你一个吧"
    );
?>